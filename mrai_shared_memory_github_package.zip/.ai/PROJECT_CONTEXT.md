# PROJECT_CONTEXT.md

## Project name

`<PROJECT_NAME>`

## Project purpose

Describe what the project does and why it exists.

## Users

- `<user group>`

## Core workflows

```text
Input → Processing → Output → Review
```

## Important modules

| Area | Folder/file | Purpose |
|---|---|---|
| Core logic | `<path>` | `<purpose>` |
| UI | `<path>` | `<purpose>` |
| Tests | `<path>` | `<purpose>` |

## Non-negotiable project values

- correctness
- traceability
- safety
- maintainability

## Uncertainties

- Needs confirmation:
