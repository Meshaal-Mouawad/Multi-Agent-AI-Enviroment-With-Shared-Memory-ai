# REPOSITORY_SCOPE.md

## Canonical source of truth

Agents MAY inspect these when relevant:

- `<core source folder>/`
- `<templates folder>/`
- `<configuration files>`
- `<tests folder>`
- `.ai/`

## Generated diagnostic evidence

Agents MAY inspect generated outputs only when debugging output.

Generated files are evidence, not repair targets.

## Do not patch as final fix

- generated output
- compiled files
- build folders
- exported reports

Fix the upstream source instead.

## Rule

Never recursively scan the entire repository unless explicitly instructed.
