# START_HERE.md

## Purpose

This is the bootloader for every AI session.

Conversation history is NOT shared memory. The `.ai` folder is the shared project memory.

## Required reading order

1. `.ai/PROJECT_CONTEXT.md`
2. `.ai/ARCHITECTURE.md`
3. `.ai/SYSTEM_BEHAVIOR_SPEC.md`
4. `.ai/REPOSITORY_SCOPE.md`
5. `.ai/AI_IGNORE.md`
6. `.ai/CURRENT_STATE.md`
7. `.ai/HANDOFF.md`
8. `.ai/BUGS.md`
9. `.ai/DECISIONS.md`
10. `.ai/CHANGELOG.md`
11. `.ai/LESSONS_LEARNED.md`

## Before editing code

Respond with:
1. What you understand the project is.
2. Which subsystem is relevant.
3. Which files you need to inspect.
4. A safe plan.
5. Verification steps.
6. Whether this is best for a cheap agent, strong agent, or human review.

## Repository scope rule

Do not recursively scan the whole repository unless explicitly instructed.

Read `.ai/REPOSITORY_SCOPE.md` and `.ai/AI_IGNORE.md` before repository analysis.

## Generated output rule

Generated files may be inspected as diagnostic evidence, but must not be patched as the final fix.

Fix the upstream source instead.

## Human verification rule

After implementation:
1. Explain root cause.
2. Explain changed files.
3. Recommend verification steps.
4. Wait for human confirmation before marking the issue resolved.

## Before ending

Update:
- `.ai/CURRENT_STATE.md`
- `.ai/HANDOFF.md`
- `.ai/CHANGELOG.md`
- `.ai/BUGS.md` if risk changed
- `.ai/DECISIONS.md` if a decision changed
- `.ai/LESSONS_LEARNED.md` if a mistake should not repeat
- `.ai/SESSIONS/YYYY-MM-DD-topic.md` for long sessions

## Never

- Do not invent project facts.
- Do not patch generated output as the final fix.
- Do not make broad refactors during critical debugging.
- Do not claim shared memory was updated unless files were actually modified.
