# end_session_update_memory.md

Before ending this session, update shared memory.

Update:
- `.ai/CURRENT_STATE.md`
- `.ai/HANDOFF.md`
- `.ai/CHANGELOG.md`
- `.ai/BUGS.md` if needed
- `.ai/DECISIONS.md` if needed
- `.ai/LESSONS_LEARNED.md` if needed
- `.ai/SESSIONS/YYYY-MM-DD-topic.md` for long sessions

Final report:
1. Which files changed.
2. Why.
3. Verification evidence.
4. Remaining risks.
