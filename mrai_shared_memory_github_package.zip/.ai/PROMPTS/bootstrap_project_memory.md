# bootstrap_project_memory.md

Read `.ai/START_HERE.md`.

Task:
Analyze this repository and fill/update the shared memory files.

Do not modify application code.

Update only:
- `.ai/PROJECT_CONTEXT.md`
- `.ai/ARCHITECTURE.md`
- `.ai/CURRENT_STATE.md`
- `.ai/REPOSITORY_SCOPE.md`
- `.ai/AI_IGNORE.md`
- `.ai/HANDOFF.md`
- `.ai/CHANGELOG.md`

Rules:
- Do not invent facts.
- Mark uncertainty as `Needs confirmation`.
- Avoid scanning ignored folders.
