# implement_plan.md

Read `.ai/START_HERE.md`.

Implement the approved plan below.

Plan:
`<paste plan>`

Rules:
- Keep changes minimal.
- Do not hardcode output.
- Do not patch generated artifacts as the final fix.
- Preserve system invariants.
- Ask for human verification before marking resolved.

After implementation:
- summarize changes
- provide verification steps
- update shared memory
