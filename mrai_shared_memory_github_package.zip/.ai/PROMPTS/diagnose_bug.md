# diagnose_bug.md

Read `.ai/START_HERE.md`.

Do not edit code.

Problem:
`<describe problem>`

Task:
1. Identify the root cause.
2. List affected files.
3. Explain why previous attempts failed.
4. Propose the safest fix.
5. Provide verification steps.
6. Write an implementation prompt for another agent.
7. Update shared memory with durable findings.
