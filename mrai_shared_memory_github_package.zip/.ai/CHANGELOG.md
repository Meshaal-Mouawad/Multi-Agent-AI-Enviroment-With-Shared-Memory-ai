# CHANGELOG.md

## Template

### YYYY-MM-DD — Agent — Change title

- What changed:
- Why:
- Files affected:
- Verification:
- Follow-up:
