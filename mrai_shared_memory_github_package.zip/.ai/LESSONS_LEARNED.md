# LESSONS_LEARNED.md

## Lesson template

### LESSON-XXX — Title

**Problem:**  
`<what went wrong>`

**Root cause:**  
`<why>`

**Correct rule:**  
`<what to do next time>`

**Verification pattern:**  
`<how to confirm it is fixed>`

**Never again:**  
`<explicit anti-pattern>`
