# DECISIONS.md

## Decision template

### YYYY-MM-DD — Decision title

**Decision:**  
`<decision>`

**Reason:**  
`<why>`

**Impact:**  
`<impact>`

**Do not reverse unless:**  
`<condition>`
