# SYSTEM_BEHAVIOR_SPEC.md

## Purpose

Define behavior agents must preserve.

## System identity

This project is:
- `<identity>`

This project is NOT:
- `<anti-identity>`

## Invariants

- Preserve correctness.
- Preserve traceability.
- Preserve user trust.
- Fail safely.

## Forbidden shortcuts

- Do not fake output.
- Do not hardcode results.
- Do not remove checks to make errors disappear.
