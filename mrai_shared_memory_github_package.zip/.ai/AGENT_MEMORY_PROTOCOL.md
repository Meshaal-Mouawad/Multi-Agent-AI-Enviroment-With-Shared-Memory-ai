# AGENT_MEMORY_PROTOCOL.md

## Principle

Reasoning is not memory.

Only written, durable information in `.ai` is shared memory.

## Workflow

1. Read `START_HERE.md`.
2. Read task-relevant files.
3. Diagnose before coding.
4. Propose safe plan.
5. Implement narrowly.
6. Ask human to verify when appropriate.
7. Update shared memory.
8. Report what changed.

## Final report required

1. `.ai` files modified.
2. Application files modified.
3. Why changes were made.
4. Verification evidence.
5. Remaining risks.

If no `.ai` files were modified, state:

> Shared memory was NOT updated.
