# SESSIONS

Use this folder for compressed summaries of long sessions.

File format:

`YYYY-MM-DD-topic.md`

Keep:
- durable facts
- root causes
- decisions
- verification results
- next actions

Remove:
- emotional chat
- duplicate explanations
- failed attempts unless useful
