# ARCHITECTURE.md

## High-level architecture

```text
Input Layer
  ↓
Processing Layer
  ↓
Storage / Memory Layer
  ↓
Interface Layer
  ↓
Output Layer
```

## Components

| Component | Responsibility | Source of truth |
|---|---|---|
| `<component>` | `<responsibility>` | `<file/folder>` |

## Architectural constraints

- Do not bypass the main pipeline.
- Do not hardcode generated output.
- Do not remove validation or traceability.
