# AI_IGNORE.md

## Ignore unless explicitly requested

- `.git/`
- `.venv/`
- `venv/`
- `node_modules/`
- `__pycache__/`
- `.pytest_cache/`
- `.mypy_cache/`
- `.DS_Store`
- `dist/`
- `build/`
- `coverage/`
- `archive/`
- `old_versions/`
- `backups/`
- `screenshots/`
- `experiments/`
- `figma_exports/`
- large binary files

## Important

Generated files may be inspected as evidence when needed, but must never become the source of truth.
