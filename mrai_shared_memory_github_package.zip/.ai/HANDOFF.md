# HANDOFF.md

## Last session

Agent:
Task:
Date:

## Work completed

- `<completed work>`

## Root cause / key findings

- `<finding>`

## Files changed

- `<file>` — `<reason>`

## Verification

- `<verification>` — `<result>`

## Next recommended action

- `<next action>`

## Warnings for next agent

- `<warning>`
