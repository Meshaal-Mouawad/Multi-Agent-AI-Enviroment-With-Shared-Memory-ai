# AGENT_ROLES.md

## Strong diagnosis agent

Use for:
- hard bugs
- architecture
- deep root cause analysis
- final review

## Implementation agent

Use for:
- applying clear plans
- refactoring
- creating files
- running local commands

## Reviewer agent

Use for:
- checking diffs
- identifying risks
- testing assumptions

## Human owner

Responsible for:
- final approval
- business truth
- risk acceptance
- domain decisions
