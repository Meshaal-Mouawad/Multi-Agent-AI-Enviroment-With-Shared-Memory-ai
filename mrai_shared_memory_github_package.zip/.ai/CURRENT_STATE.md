# CURRENT_STATE.md

## Current phase

`<current phase>`

## Current objective

`<objective>`

## Active task

`<task>`

## Current blockers

- `<blocker>`

## Next action

`<next action>`
