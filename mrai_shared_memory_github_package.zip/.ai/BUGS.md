# BUGS.md

## Template

### RISK-XXX — Title

**Status:** Open | Investigating | Resolved | Monitoring  
**Severity:** Low | Medium | High | Critical  
**Area:** `<subsystem>`

**Description:**  
`<description>`

**Root cause:**  
`<root cause if known>`

**Affected files:**  
- `<file>`

**Next action:**  
- `<next action>`
